<p> {{ $block['text'] }} </p>
@include('partials.page-builder.partials.heading')
