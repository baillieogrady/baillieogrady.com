<h1>{!! $block['heading'] !!}</h1>
