@extends('layouts.app')

@section('content')
<div class="container">
    @include('partials.page-header')
    <div class="alert alert-warning">
      <p style="font-size: 2.5rem">
        Please use the navigation above.
      </p>
    </div>
  </div>
@endsection
