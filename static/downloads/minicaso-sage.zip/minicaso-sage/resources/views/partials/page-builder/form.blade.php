<section class="form text-center">
  <div class="container">
    <div class="row no-gutters">
      <div class="col-lg-6">
        {{-- {!! $block['heading'] !!} --}}
        {!! $block['shortcode'] !!}
      </div>
    </div>
  </div>
</section>