<section class="text {{  $block['remove_margin'] === true ? 'nmb' : '' }}">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        {!! $block['content'] !!}
      </div>
    </div>
  </div>
</section>