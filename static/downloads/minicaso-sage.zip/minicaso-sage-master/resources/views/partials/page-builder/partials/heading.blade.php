<div  data-aos="fade-down" data-aos-delay="300">
  {!! $block['heading'] !!}
</div>